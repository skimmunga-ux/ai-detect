import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export type HumanizeTone = "Natural" | "Casual" | "Professional" | "Academic" | "Creative";
export type OperationMode = "HUMANIZE" | "EDIT" | "WRITE_HUMANIZE" | "WRITE_ONLY";

export interface HumanizeOptions {
  tone: HumanizeTone;
  intensity: number; // 0 to 100
  mode: OperationMode;
  pageCount?: number;
}

export async function processContent(input: string, options: HumanizeOptions): Promise<string> {
  const { tone, intensity, mode, pageCount } = options;
  
  let prompt = "";
  let systemInstruction = "";

  if (mode === "WRITE_HUMANIZE" || mode === "WRITE_ONLY") {
    const pages = pageCount || 1;
    const wordCount = pages * 450; // Standard 12pt double-spaced page is ~250-300 words, single-spaced is ~500. Let's aim for ~450.
    
    systemInstruction = `You are a professional long-form academic and technical writer. 
Your task is to write an extensive, high-quality project on the provided topic.
Target Length: Approximately ${wordCount} words (roughly ${pages} standard pages).

Formatting Requirements:
1. Use a clear hierarchy of headings (H1 for Title, H2 for Chapters, H3 for Sections).
2. Ensure each section is detailed and provides deep insight.
3. Maintain a professional, authoritative voice.
4. ${mode === "WRITE_HUMANIZE" ? "IMPORTANT: Write this in a way that is easy to humanize later, but focus on depth first." : "Write this in a standard professional style."}

Structure:
- Title Page (Title, Subtitle)
- Table of Contents (List the sections)
- Introduction
- Main Body Chapters (Detailed exploration)
- Conclusion
- References/Bibliography`;
    
    prompt = `Topic: ${input}\n\nPlease write a comprehensive ${pages}-page project on this topic. Ensure the depth justifies the page count.`;
  } else if (mode === "HUMANIZE") {
    systemInstruction = `You are a world-class ghostwriter and linguistic expert. Your mission is to "de-robotize" AI-generated text so it is indistinguishable from high-quality human writing. 

CRITICAL OBJECTIVE: The output MUST pass 100% human scores on AI detectors (like GPTZero, Originality.ai, etc.).

Linguistic Strategy for 100% Human Score:
1. **Extreme Burstiness**: Humans don't write in rhythmic patterns. Mix very short sentences (3-5 words) with long, complex ones (25+ words). Use fragments for emphasis if the tone allows.
2. **High Perplexity**: Use synonyms that are contextually perfect but less "statistically probable" for an LLM. Avoid "AI-isms": "delve", "tapestry", "comprehensive", "moreover", "unlock", "vibrant", "testament".
3. **Syntactic Variety**: Start sentences with different parts of speech (prepositions, gerunds, adverbs), not just "The [Subject] [Verb]".
4. **Human Nuance**: Include subtle rhetorical questions, parenthetical asides (like this), and occasional idiomatic expressions.
5. **Tone Profile**: ${tone}.
6. **Intensity Level**: ${intensity}%. 
   - At 100% intensity, you have full creative license to completely reorder paragraphs and rephrase every single sentence to maximize "human-ness".

Rules:
- Do NOT use bullet points unless strictly necessary.
- Do NOT use "In conclusion" or "Lastly".
- Maintain the core message but destroy the "AI structure".
- Return ONLY the rewritten text. No preamble.`;
    prompt = input;
  } else if (mode === "EDIT") {
    systemInstruction = `You are a professional editor. Your task is to refine the provided text for clarity, grammar, and professional flow. 
Do not change the meaning or the core voice, just make it "polished".
- Fix all grammatical errors.
- Improve sentence transitions.
- Ensure consistent tone: ${tone}.
- Return ONLY the edited text.`;
    prompt = input;
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: mode.includes("HUMANIZE") ? 0.9 + (intensity / 1000) : 0.7,
        topP: 0.95,
        topK: 64,
      },
    });

    let result = response.text || "SYSTEM ERROR: CONTENT GENERATION FAILED.";

    // If we are in WRITE_HUMANIZE mode, we need a second pass to humanize the generated text
    if (mode === "WRITE_HUMANIZE" && result !== "SYSTEM ERROR: CONTENT GENERATION FAILED.") {
      return await processContent(result, { ...options, mode: "HUMANIZE" });
    }

    return result;
  } catch (error) {
    console.error("Content processing error:", error);
    throw new Error("CONNECTION INTERRUPTED: CLOUD UPLINK FAILED.");
  }
}
