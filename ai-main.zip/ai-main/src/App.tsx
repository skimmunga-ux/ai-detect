/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect } from 'react';
import { 
  Terminal, 
  Copy, 
  Check, 
  RotateCcw, 
  Cpu, 
  ShieldAlert, 
  Zap,
  Loader2,
  AlertTriangle,
  ChevronRight,
  Eye,
  Activity,
  FileText,
  FileDown,
  Layers,
  FileSpreadsheet,
  File as FileIcon,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import ReactMarkdown from 'react-markdown';
import { processContent, type HumanizeTone, type HumanizeOptions, type OperationMode } from './services/geminiService';
import { jsPDF } from 'jspdf';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import * as XLSX from 'xlsx';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const TONES: HumanizeTone[] = ["Natural", "Casual", "Professional", "Academic", "Creative"];
const MODES: { id: OperationMode; label: string; desc: string }[] = [
  { id: "WRITE_HUMANIZE", label: "Write + Humanize", desc: "Full project generation with bypass." },
  { id: "HUMANIZE", label: "Humanize Only", desc: "Aggressive AI detection bypass." },
  { id: "EDIT", label: "Edit Only", desc: "Professional polish and grammar." },
  { id: "WRITE_ONLY", label: "Write Only", desc: "Standard AI content generation." },
];

export default function App() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [options, setOptions] = useState<HumanizeOptions>({
    tone: "Natural",
    intensity: 100,
    mode: "HUMANIZE",
    pageCount: 1,
  });
  const [terminalLines, setTerminalLines] = useState<string[]>(['> INITIALIZING GHOST_WRITER OS...', '> UPLINK STABLE.']);

  const addTerminalLine = (line: string) => {
    setTerminalLines(prev => [...prev.slice(-4), line]);
  };

  const handleProcess = async () => {
    if (!input.trim()) return;
    
    setIsProcessing(true);
    setError(null);
    
    if (options.mode.includes("WRITE")) {
      addTerminalLine(`> GENERATING ${options.pageCount} PAGE PROJECT...`);
    } else {
      addTerminalLine(`> ANALYZING LINGUISTIC PATTERNS...`);
    }
    
    try {
      const result = await processContent(input, options);
      setOutput(result);
      addTerminalLine(`> OPERATION SUCCESSFUL. DATA DECRYPTED.`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'UPLINK ERROR.';
      setError(msg);
      addTerminalLine(`> ERROR: ${msg}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = useCallback(() => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    addTerminalLine(`> BUFFER COPIED.`);
    setTimeout(() => setCopied(false), 2000);
  }, [output]);

  const exportPDF = () => {
    const doc = new jsPDF();
    const margin = 20;
    const pageWidth = doc.internal.pageSize.getWidth();
    const contentWidth = pageWidth - (margin * 2);
    let cursorY = margin;

    const lines = output.split('\n');
    lines.forEach(line => {
      if (line.startsWith('# ')) {
        doc.setFontSize(24);
        doc.setFont('helvetica', 'bold');
        const text = line.replace('# ', '');
        const splitText = doc.splitTextToSize(text, contentWidth);
        doc.text(splitText, margin, cursorY);
        cursorY += (splitText.length * 10) + 5;
      } else if (line.startsWith('## ')) {
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        const text = line.replace('## ', '');
        const splitText = doc.splitTextToSize(text, contentWidth);
        doc.text(splitText, margin, cursorY);
        cursorY += (splitText.length * 8) + 4;
      } else if (line.startsWith('### ')) {
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        const text = line.replace('### ', '');
        const splitText = doc.splitTextToSize(text, contentWidth);
        doc.text(splitText, margin, cursorY);
        cursorY += (splitText.length * 6) + 3;
      } else {
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        const splitText = doc.splitTextToSize(line, contentWidth);
        
        if (cursorY + (splitText.length * 7) > doc.internal.pageSize.getHeight() - margin) {
          doc.addPage();
          cursorY = margin;
        }
        
        doc.text(splitText, margin, cursorY);
        cursorY += (splitText.length * 7) + 2;
      }
    });

    doc.save('ghost_writer_project.pdf');
    addTerminalLine(`> EXPORTED TO PDF (12PT).`);
  };

  const exportWord = async () => {
    const paragraphs = output.split('\n').map(line => {
      if (line.startsWith('# ')) {
        return new Paragraph({
          text: line.replace('# ', ''),
          heading: HeadingLevel.HEADING_1,
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
        });
      } else if (line.startsWith('## ')) {
        return new Paragraph({
          text: line.replace('## ', ''),
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 150 },
        });
      } else if (line.startsWith('### ')) {
        return new Paragraph({
          text: line.replace('### ', ''),
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 150, after: 100 },
        });
      } else {
        return new Paragraph({
          children: [new TextRun({ text: line, size: 24 })], // size is in half-points, so 24 = 12pt
          spacing: { after: 120 },
        });
      }
    });

    const doc = new Document({
      sections: [{
        properties: {},
        children: paragraphs,
      }],
    });

    const blob = await Packer.toBlob(doc);
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'ghost_writer_project.docx';
    link.click();
    addTerminalLine(`> EXPORTED TO DOCX (12PT).`);
  };

  const exportExcel = () => {
    const ws = XLSX.utils.aoa_to_sheet(output.split('\n').map(line => [line]));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Content");
    XLSX.writeFile(wb, "ghost_writer_project.xlsx");
    addTerminalLine(`> EXPORTED TO XLSX.`);
  };

  const handleReset = () => {
    setInput('');
    setOutput('');
    setError(null);
    addTerminalLine(`> SYSTEM PURGED.`);
  };

  return (
    <div className="min-h-screen bg-bg text-primary font-mono flex flex-col selection:bg-primary selection:text-black">
      <div className="scanline pointer-events-none" />
      
      {/* Header */}
      <header className="border-b border-primary/30 px-6 py-4 bg-black/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 border border-primary/50 rounded shadow-[0_0_10px_rgba(0,255,65,0.3)]">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-widest uppercase crt-flicker">
                Ghost_Writer <span className="text-xs font-normal opacity-50">PRO_V5</span>
              </h1>
              <p className="text-[10px] opacity-60 tracking-tighter">UNLIMITED GENERATION & BYPASS // SECURE</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-4 text-[10px] opacity-40">
              <div className="flex items-center gap-1"><Activity className="w-3 h-3" /> THREADS: 128</div>
              <div className="flex items-center gap-1"><Zap className="w-3 h-3" /> BUFFER: 100%</div>
            </div>
            <button 
              onClick={handleReset}
              className="text-xs font-bold hover:text-white flex items-center gap-1.5 transition-colors border border-primary/30 px-3 py-1 rounded hover:bg-primary/10"
            >
              <RotateCcw className="w-3 h-3" />
              PURGE
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Controls & Input */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Terminal Output */}
          <div className="bg-black border border-primary/20 rounded-lg p-4 h-28 overflow-hidden flex flex-col justify-end shadow-inner">
            {terminalLines.map((line, i) => (
              <div key={i} className={cn("text-[10px] mb-1", i === terminalLines.length - 1 ? "opacity-100" : "opacity-40")}>
                {line}
              </div>
            ))}
            <div className="flex items-center gap-1 text-[10px] animate-pulse">
              <span className="w-1 h-3 bg-primary" />
            </div>
          </div>

          {/* Mode Selection */}
          <div className="grid grid-cols-2 gap-2">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setOptions(prev => ({ ...prev, mode: m.id }))}
                className={cn(
                  "p-3 rounded border text-left transition-all group relative overflow-hidden",
                  options.mode === m.id 
                    ? "bg-primary text-black border-primary shadow-[0_0_15px_rgba(0,255,65,0.3)]" 
                    : "bg-black/40 text-primary/60 border-primary/20 hover:border-primary/50"
                )}
              >
                <div className="text-[10px] font-bold uppercase mb-1">{m.label}</div>
                <div className="text-[8px] opacity-70 leading-tight">{m.desc}</div>
                {options.mode === m.id && (
                  <div className="absolute top-1 right-1">
                    <Check className="w-3 h-3" />
                  </div>
                )}
              </button>
            ))}
          </div>

          {/* Input Area */}
          <div className="flex flex-col gap-2 flex-1">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2 text-primary/70">
                <Cpu className="w-3 h-3" />
                <span className="text-[10px] font-bold uppercase tracking-widest">
                  {options.mode.includes("WRITE") ? "Project_Prompt" : "Source_Data"}
                </span>
              </div>
              <span className="text-[10px] opacity-40">{input.length} CHR</span>
            </div>
            
            <div className="relative flex-1 min-h-[200px]">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={options.mode.includes("WRITE") ? "> ENTER PROJECT TOPIC & REQUIREMENTS..." : "> INJECT AI CONTENT..."}
                className="w-full h-full bg-black/40 border border-primary/30 rounded-lg p-5 text-primary placeholder:text-primary/10 focus:outline-none focus:border-primary focus:shadow-[0_0_15px_rgba(0,255,65,0.1)] transition-all resize-none font-mono text-sm leading-relaxed"
              />
            </div>
          </div>

          {/* Settings Panel */}
          <div className="bg-black/60 border border-primary/30 rounded-lg p-6 space-y-6">
            <div className="flex items-center gap-2 text-primary/70 border-b border-primary/10 pb-3">
              <ShieldAlert className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-widest">Configuration</span>
            </div>

            <div className="space-y-6">
              {options.mode.includes("WRITE") && (
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-[10px] font-bold text-primary/50 uppercase tracking-widest">Page_Count</label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="number" 
                        min="1" 
                        max="100" 
                        value={options.pageCount}
                        onChange={(e) => setOptions(prev => ({ ...prev, pageCount: Math.max(1, parseInt(e.target.value) || 1) }))}
                        className="bg-black border border-primary/30 text-primary text-xs font-bold w-12 px-1 py-0.5 focus:outline-none focus:border-primary"
                      />
                      <span className="text-[10px] font-bold text-primary/50">PAGES</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    value={options.pageCount}
                    onChange={(e) => setOptions(prev => ({ ...prev, pageCount: parseInt(e.target.value) }))}
                    className="w-full h-1 bg-primary/10 rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                  <div className="flex justify-between mt-2 opacity-30">
                    <span className="text-[8px] uppercase">Short</span>
                    <span className="text-[8px] uppercase">Extended (50+)</span>
                  </div>
                </div>
              )}

              <div>
                <label className="text-[10px] font-bold text-primary/50 uppercase tracking-widest block mb-3">Tone_Profile</label>
                <div className="grid grid-cols-3 gap-2">
                  {TONES.map((tone) => (
                    <button
                      key={tone}
                      onClick={() => setOptions(prev => ({ ...prev, tone }))}
                      className={cn(
                        "px-2 py-2 rounded border text-[10px] font-bold transition-all uppercase",
                        options.tone === tone 
                          ? "bg-primary text-black border-primary shadow-[0_0_10px_rgba(0,255,65,0.4)]" 
                          : "bg-transparent text-primary/60 border-primary/20 hover:border-primary/50"
                      )}
                    >
                      {tone}
                    </button>
                  ))}
                </div>
              </div>

              {options.mode.includes("HUMANIZE") && (
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-[10px] font-bold text-primary/50 uppercase tracking-widest">Bypass_Intensity</label>
                    <span className="text-xs font-bold text-primary">{options.intensity}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={options.intensity}
                    onChange={(e) => setOptions(prev => ({ ...prev, intensity: parseInt(e.target.value) }))}
                    className="w-full h-1 bg-primary/10 rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                </div>
              )}
            </div>

            <button
              onClick={handleProcess}
              disabled={isProcessing || !input.trim()}
              className={cn(
                "w-full py-4 rounded font-bold flex items-center justify-center gap-3 transition-all uppercase tracking-[0.2em]",
                isProcessing || !input.trim()
                  ? "bg-primary/5 text-primary/20 border border-primary/10 cursor-not-allowed"
                  : "bg-primary text-black hover:bg-white hover:shadow-[0_0_20px_rgba(255,255,255,0.5)] active:scale-[0.98]"
              )}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  PROCESSING...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 fill-current" />
                  EXECUTE_UPLINK
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Output */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2 text-primary/70">
              <Eye className="w-3 h-3" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Decrypted_Output</span>
            </div>
            <div className="flex items-center gap-2">
              {output && (
                <>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-2 text-[10px] font-bold text-primary hover:text-white transition-colors border border-primary/30 px-3 py-1 rounded bg-primary/5"
                  >
                    {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'COPIED' : 'COPY'}
                  </button>
                  <div className="w-px h-4 bg-primary/20 mx-1" />
                  <div className="flex items-center gap-1">
                    <button onClick={exportPDF} title="Export PDF" className="p-1.5 border border-primary/30 rounded hover:bg-primary/10 text-primary transition-all">
                      <FileText className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={exportWord} title="Export Word" className="p-1.5 border border-primary/30 rounded hover:bg-primary/10 text-primary transition-all">
                      <FileIcon className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={exportExcel} title="Export Excel" className="p-1.5 border border-primary/30 rounded hover:bg-primary/10 text-primary transition-all">
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className={cn(
            "flex-1 bg-black/40 border border-primary/30 rounded-lg p-8 overflow-auto relative group",
            !output && "flex items-center justify-center text-primary/20 italic text-sm"
          )}>
            <AnimatePresence mode="wait">
              {error ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center gap-4 text-red-500 text-center max-w-md"
                >
                  <AlertTriangle className="w-12 h-12 animate-pulse" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold uppercase tracking-widest">Critical_Failure</p>
                    <p className="text-xs opacity-70">{error}</p>
                  </div>
                  <button 
                    onClick={handleProcess}
                    className="text-[10px] border border-red-500/50 px-4 py-2 rounded hover:bg-red-500/10 transition-all uppercase font-bold"
                  >
                    RETRY_UPLINK
                  </button>
                </motion.div>
              ) : output ? (
                <motion.div
                  key="output"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="markdown-body leading-relaxed"
                >
                  <ReactMarkdown>{output}</ReactMarkdown>
                </motion.div>
              ) : (
                <motion.div
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center space-y-3"
                >
                  <div className="flex justify-center gap-2 opacity-20">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <p className="uppercase tracking-widest text-[10px]">Waiting for data injection...</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Corner Accents */}
            <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary/40 rounded-tl" />
            <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-primary/40 rounded-tr" />
            <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-primary/40 rounded-bl" />
            <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary/40 rounded-br" />
          </div>
          
          {/* System Status Footer */}
          <div className="bg-black border border-primary/30 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-6">
              <div className="flex flex-col">
                <span className="text-[8px] uppercase opacity-40">Export_Modules</span>
                <span className="text-[10px] text-primary">PDF / DOCX / XLSX</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[8px] uppercase opacity-40">Max_Pages</span>
                <span className="text-[10px] text-primary">50+ (UNLIMITED)</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[8px] uppercase opacity-40">Mode</span>
                <span className="text-[10px] text-primary">{options.mode}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-2 bg-primary/10 px-3 py-1.5 rounded border border-primary/20">
              <ChevronRight className="w-3 h-3 text-primary" />
              <span className="text-[10px] font-bold text-primary animate-pulse">UPLINK_STABLE</span>
            </div>
          </div>
        </div>
      </main>

      {/* Background Noise/Overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] mix-blend-overlay bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
    </div>
  );
}




